package com.example.payfromhome;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {}
